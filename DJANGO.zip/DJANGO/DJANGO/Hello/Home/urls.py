from django.contrib import admin
from django.urls import path
from Home import views

urlpatterns = [
    path("", views.index, name='Home'),
        path("home", views.home, name='Home'),
    path("about",views.about, name='about'),
    path("services",views.services, name='services'),
     path("contact",views.contact, name='contact'),
     path("help",views.help, name='help'),
     path("viewdetails",views.viewdetails, name='viewdetails'),
      path("demon",views.demon, name='demon'),
       path("death",views.death, name='death'),
       path("jk",views.jk, name='jujutsu kiasein'),
]






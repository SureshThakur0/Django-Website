from django.shortcuts import render, HttpResponse
from datetime import datetime
from Home.models import Contact
# Create your views here.
def index(request):
    context= {
        "variable1" : "i am suresh",
         "variable2" : "i am op"
    }
    return render ( request, 'index.html', )

def home(request):
    return render ( request, 'home.html', )
    # return HttpResponse("this is about page")
def about(request):
    return render ( request, 'about.html', )
    # return HttpResponse("this is about page")

def services(request):
    return render ( request, 'services.html', )
    # return HttpResponse("this is services page")

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact (name=name, email=email, phone=phone, desc=desc, date=datetime.today())
        contact.save()
     
    return render ( request, 'contact.html', )
    # return HttpResponse("this is contact page")

def help(request):
    
    return render ( request, 'help.html',)
    # return HttpResponse("this is help page")

def viewdetails(request):
    return render ( request, 'viewdetails.html', )
    # return HttpResponse("this is viewdetails page")

def demon(request):
    return render ( request, 'demon.html', )

def death(request):
    return render ( request, 'death.html', )
def jk(request):
    return render ( request, 'jk.html', )